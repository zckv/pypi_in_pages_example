# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['example_package']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['hello = example_package.hello:main']}

setup_kwargs = {
    'name': 'example-package',
    'version': '0.1.0',
    'description': 'Example python project',
    'long_description': None,
    'author': 'Zackarie Vinckier',
    'author_email': 'zackarie.vinckier--coffinier@atos.net',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)

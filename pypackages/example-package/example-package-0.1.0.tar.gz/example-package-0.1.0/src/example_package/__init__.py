# src/example_package/__init__.py
__version__ = "0.1.0"
